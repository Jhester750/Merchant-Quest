
import java.awt.*;
import java.applet.*;
import java.util.Random;
/**
 * Class WorldWar - write a description of the class here
 * 
 * @author Jack + Neil 
 * @version March 15, 2019 3:07 PM
 */
public class WorldWar extends Applet implements Runnable {
    Graphics bufferGraphics;
    Image display;
    boolean isRight=false;
    boolean isLeft=false;
    boolean isRunning=true;
    double playerShipX=250;
    double playerShipY=400;
    int shipWidth=24;
    Image playerShip;
    Image enemyShip;
    Image fireball;
    double enemyShipX=250;
    double enemyShipY=0;
    int lives=3;
    Random rand = new Random();
    public static final int SIZE = 70;
    int distance=2000;
    String dMessage;
    String lMessage;
    String loseMessage;
    String winMessage;
    String levelMessage;
    boolean isContinue=false;
    int Level=1;
    int speed=3;
    public void init()
    {
        setBackground(Color.blue);
        display=createImage(getSize().width,getSize().height);
        bufferGraphics=display.getGraphics();
        playerShip=getImage(getDocumentBase(), "playerShipNew.png");
        enemyShip=getImage(getDocumentBase(), "enemyShip.png");
        fireball=getImage(getDocumentBase(), "fireball.png");
        new Thread(this).start();
    }

    public void run()
    {
        while (isRunning==true){
            winMessage="You won, press space bar to continue";
            if (distance >0){
                if (isRight==true){
                    if (playerShipX<getSize().width-shipWidth){
                        playerShipX+=6;
                    }
                }
                if (isLeft==true){
                    if (playerShipX>0){
                        playerShipX-=10;
                    }
                }
                if (enemyShipY > 500-SIZE){
                    enemyShipY= 0;
                    enemyShipX = rand.nextInt(500-SIZE);
                }
                else{
                    enemyShipY +=speed;
                }
                distance-=1;
            }
            
             
           dMessage= "You are "+distance+" miles from shore";
           lMessage="You have " + lives + " lives left";
           loseMessage="The Germans have sunk your ship! You have lost...";
           levelMessage= "Level: "+Level;
           repaint();
           try  {
               Thread.sleep(32);
            }
            catch(InterruptedException e){
            }
        }
             
    }
      
    public void paint(Graphics g)
    {
    if (distance>0){
        g.drawImage(display,0,0,this);
        g.drawImage(playerShip, (int)playerShipX, (int)playerShipY, SIZE, SIZE, this);
        g.drawImage(enemyShip, (int)enemyShipX, (int)enemyShipY, SIZE, SIZE, this);
        g.drawString(dMessage, 20, 20);
        g.drawString(lMessage, 20, 50);
        g.drawString(levelMessage, 350,20);
        if (((playerShipX > enemyShipX-SIZE) &&(playerShipX < enemyShipX+SIZE))&&((playerShipY > enemyShipY-SIZE) &&(playerShipY < enemyShipY+SIZE))){
            g.drawImage(fireball,(int)playerShipX-SIZE/2, (int)playerShipY-SIZE/2, SIZE*2, SIZE*2, this);
            lives-=1;
            enemyShipY-=playerShipY;
            if (lives==0){
                g.drawString(loseMessage, 50, 100);
                isRunning=false;
            }
        }
    }
    else if (distance==0){
        g.drawImage(display,0,0,this);
        g.drawString(winMessage, 50, 100); 
    }
}
    
    public boolean keyDown (Event e, int key){
        if (key==Event.LEFT){
            isLeft=true;
        }
        if (key==Event.RIGHT){
            isRight=true;
        }
        if ((key==32) && (distance==0)){
            distance=2000;
            Level+=1;
            lives=3;
            speed+=1;
        }
        System.out.println("Integer Value: " + key);
        return true;
    }
    
    public boolean keyUp(Event e, int key){
        if (key==Event.LEFT){
            isLeft=false;
        }
        if (key==Event.RIGHT){
            isRight=false;
        }
        return true;
    }

}

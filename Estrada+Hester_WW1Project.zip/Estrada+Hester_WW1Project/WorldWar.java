
import java.awt.*;
import java.applet.*;

/**
 * Class WorldWar - write a description of the class here
 * 
 * @author (your name) 
 * @version (a version number)
 */
public class WorldWar extends Applet implements Runnable {
    Graphics bufferGraphics;
    Image display;
    boolean isRight=false;
    boolean isLeft=false;
    int direction=1;
    double shipX=250;
    int shipWidth=24;
    
    public void init()
    {
        setBackground(Color.blue);
        display=createImage(getSize().width,getSize().height);
        bufferGraphics=display.getGraphics();
        new Thread(this).start();
    }

    public void run()
    {
        for(;;){
            if (isRight==true){
                if (shipX<getSize().width-shipWidth){
                    shipX+=1;
                }
            }
            if (isLeft==true){
                if (shipX>0){
                    shipX-=1;}
           }
           repaint();
           try  {
               Thread.sleep(16);
            }
            catch(InterruptedException e){
            }
        }
                
    }

    public void update(Graphics g)
    {
        bufferGraphics.clearRect(0,0,getSize().width,getSize().width);
        bufferGraphics.setColor(Color.orange);
        bufferGraphics.fillRect((int)shipX, 375, 24, 24);
        g.drawImage(display,0,0,this);
    }
    
    public boolean keyDown (Event e, int key){
        if (key==Event.LEFT){
            isLeft=true;
        }
        if (key==Event.RIGHT){
            isRight=true;
        }
        System.out.println("Integer Value: " + key);
        return true;
    }
    
    public boolean keyUp(Event e, int key){
        if (key==Event.LEFT){
            isLeft=false;
        }
        if (key==Event.RIGHT){
            isRight=false;
        }
        return true;
    }
   
}


import java.awt.*;
import java.applet.*;
import java.util.Random;
/**
 * Class WorldWar - write a description of the class here
 * 
 * @author Jack + Neil 
 * @version March 15, 2019 3:07 PM
 */
public class WorldWar extends Applet implements Runnable {
    Graphics bufferGraphics;
    Image display;
    boolean isRight=false;
    boolean isLeft=false;
    boolean isRunning=true;
    double playerShipX=250;
    double playerShipY=400;
    int shipWidth=24;
    Image playerShip;
    Image enemyShip;
    Image fireball;
    Image torpedo;
    Image kaiser;
    Image wave1;
    Image wave2;
    double enemyShipX=250;
    double enemyShipY=0;
    double torpedoX=0;
    double torpedoY=0;
    double kaiserX=150;
    double kaiserY=-100;
    double wave1X=40;
    double wave1Y=40;
    double wave2X=400;
    double wave2Y=400;
    int lives=3;
    Random rand = new Random();
    public static final int SIZE = 70;
    public static final int KAISERSIZE= 150;
    int distance=0;
    String dMessage;
    String lMessage;
    String loseMessage;
    String winMessage;
    String levelMessage;
    boolean isContinue=false;
    int Level=0;
    int speed=5;
    Font Header;
    Font Body;
    AudioClip clip;
    public void init()
    {
        setBackground(Color.blue);
        display=createImage(getSize().width,getSize().height);
        bufferGraphics=display.getGraphics();
        playerShip=getImage(getDocumentBase(), "playerShipNew.png");
        enemyShip=getImage(getDocumentBase(), "enemyShip.png");
        fireball=getImage(getDocumentBase(), "fireball.png");
        torpedo=getImage(getDocumentBase(), "torpedo.png");
        kaiser=getImage(getDocumentBase(), "kaiser.gif");
        wave1=getImage(getDocumentBase(), "waves.png");
        wave2=getImage(getDocumentBase(), "waves.png");
        clip=getAudioClip(getDocumentBase(), "NavalSong.wav");
       Header = new Font("Elephant",Font.BOLD,34);    
       Body = new Font("Arial",Font.PLAIN,16);    
        new Thread(this).start();
    }

    public void run()
    {
        clip.loop();
        while (isRunning==true){
            if (distance >0){
                if (distance%60==0){
                    wave1X=40;
                    wave1Y=40;
                    wave2X=400;
                    wave2Y=400;
                }
                else if (distance%30==0){
                    wave1X=400;
                    wave1Y=40;
                    wave2X=40;
                    wave2Y=400;
                }
                if (isRight==true){
                    if (playerShipX<getSize().width-shipWidth){
                        playerShipX+=10;
                    }
                }
                if (isLeft==true){
                    if (playerShipX>0){
                        playerShipX-=10;
                    }
                }
                if (enemyShipY > 500-SIZE){
                    enemyShipY= 0;
                    enemyShipX = rand.nextInt(500-SIZE);
                }
                else{
                    enemyShipY +=speed;
                }
                if (Level >= 2){
                    if (torpedoY > 500-SIZE){
                        torpedoY= 0;
                        torpedoX = rand.nextInt(500-SIZE);
                    }
                    else{
                        torpedoY +=speed-2;
                    }
                }
                if ((Level==3) &&(distance< 600)){
                    if (kaiserY > 500-KAISERSIZE){
                        kaiserY= -100;
                        kaiserX = rand.nextInt(500-KAISERSIZE);
                    }
                    else{
                        kaiserY +=2;
                    }
                }
                distance-=1;
            }
            
             
           dMessage= "You are "+distance+" miles from shore";
           lMessage="You have " + lives + " lives left";
           loseMessage="The Germans have sunk your ship! You have lost...";
           levelMessage= "Level: "+Level;
           repaint();
           try  {
               Thread.sleep(32);
            }
            catch(InterruptedException e){
            }
        }
             
    }
      
    public void paint(Graphics g)
    {
    if (distance>0){
        g.drawImage(display,0,0,this);
        g.drawImage(wave1, (int)wave1X, (int)wave1Y, SIZE, SIZE, this);
        g.drawImage(wave2, (int)wave2X, (int)wave2Y, SIZE, SIZE, this);
        g.drawImage(playerShip, (int)playerShipX, (int)playerShipY, SIZE, SIZE, this);
        g.drawImage(enemyShip, (int)enemyShipX, (int)enemyShipY, SIZE, SIZE, this);
        if (Level >= 2){
            g.drawImage(torpedo, (int)torpedoX, (int)torpedoY, SIZE, SIZE, this);
        }
        if ((Level ==3) &&(distance <600)){
            g.drawImage(kaiser, (int)kaiserX, (int)kaiserY, KAISERSIZE, KAISERSIZE, this);
        }
        if (lives ==0){
            g.setFont(Body); 
            g.setColor(Color.white);
            g.drawString(loseMessage, 50, 100);
            g.drawImage(fireball,(int)playerShipX-SIZE/2, (int)playerShipY-SIZE/2, SIZE*2, SIZE*2, this);
            isRunning=false;
        }
        g.setColor(Color.white);
        g.setFont(Body); 
        g.drawString(dMessage, 20, 20);
        g.drawString(lMessage, 20, 50);
        g.drawString(levelMessage, 350,20);
        if ((((playerShipX > enemyShipX-SIZE) &&(playerShipX < enemyShipX+SIZE))&&((playerShipY > enemyShipY-SIZE) &&(playerShipY < enemyShipY+SIZE))) || 
        (((playerShipX > torpedoX-SIZE) &&(playerShipX < torpedoX+SIZE))&&((playerShipY > torpedoY-SIZE) &&(playerShipY < torpedoY+SIZE))) ||
        (((playerShipX > kaiserX-SIZE) &&(playerShipX < kaiserX+KAISERSIZE-SIZE))&&((playerShipY > kaiserY-KAISERSIZE) &&(playerShipY < kaiserY+KAISERSIZE))))
        {
            g.drawImage(fireball,(int)playerShipX-SIZE/2, (int)playerShipY-SIZE/2, SIZE*2, SIZE*2, this);
            lives-=1;
            enemyShipY=0;
            torpedoY=0;
            kaiserY=-100;
        }
    }
    else if (distance==0){
        g.drawImage(display,0,0,this);
        switch(Level){
            case 0:
                g.setColor(Color.YELLOW);
                g.setFont(Header);  
                g.drawString("Merchant Quest", 100, 150);
                g.setFont(Body);  
                g.drawString("By Jack Hester and Neil Estrada.", 140, 200);
                g.drawString("The game about being an allied merchant during World War 1.", 20, 300);
                g.drawString("In this game you will be an American merchant ship with ", 20, 350);
                g.drawString("various goods you need to bring to England. Unfortunately,", 20, 370);
                g.drawString("there are many u-boats obstructing your course. You must ", 20, 390);
                g.drawString("dodge these boats or else your ship will sink and the Kaiser ", 20, 410);
                g.drawString("will prevail over freedom and democracy! Good luck Captain! ", 20, 430);
                break;
            case 1:
               g.setColor(Color.YELLOW);
                g.setFont(Body);
                g.drawString("Your ship was ambushed by German U-Boats!", 90, 50);
                g.drawString("However, you lived to sail another mission.", 100, 70);
                g.drawString("In the early years of the 20th century, the British Navy ", 20, 150);
                g.drawString("thought that the next major war fought in waters would end", 20, 170);
                g.drawString("up using battleships, such as the HMS Dreadnought, a large ", 20, 190);
                g.drawString("British warship that ended up being the first of its kind.", 20, 210);
                g.drawString("However in the year of 1915, Germany had declared a war zone ", 20, 230);
                g.drawString("around the British Isles, sinking any and all allied ships ", 20, 250);
                g.drawString("that entered these boundaries using German submarines known", 20, 270);
                g.drawString("as U-Boats.", 200, 290);
                g.drawString("", 20, 350);
                g.drawString("U-Boats come from the German word “unterseeboot” which ", 20, 320);
                g.drawString("translates literally to “undersea boat”. U-Boats mainly ", 20, 340);
                g.drawString("utilized torpedoes in order to sink allied ships, though", 20, 360);
                g.drawString("they did use mounted machines guns and mines when the", 20, 380);
                g.drawString("submarine were above the surface of the water. Prior to ", 20, 400);
                g.drawString("initiating unrestricted submarine warfare, the German navy ", 20, 420);
                g.drawString("took action to sink the HMS Pathfinder, a British ship and ", 20, 440);
                g.drawString("the very first one to be sunk by a torpedo launched from a  ", 20, 460);
                g.drawString("submarine.The attack of Pathfinder resulted in the loss of 250", 20, 480);
                g.drawString("lives, while only 18 members of her crew survived.", 60, 500);
                break;
            case 2:
                g.setColor(Color.YELLOW);
                g.setFont(Body);
                g.drawString("Great work captain, that was a close call! It seems that those ", 20, 50);
                g.drawString("Germans are unfortunately getting much better at piloting those", 20, 70);
                g.drawString("subs. However, we have faith in you for your final mission.", 35, 90);
                g.drawString("Over the course of The Great War, German U-Boats managed to sink", 20, 130);
                g.drawString("over 5,000 ships, which was a far cry from the 178 U-Boats sunk ", 20, 150);
                g.drawString("in combat,  proving that the German navy was truly a force to be ", 20, 170);
                g.drawString("reckoned with. This practice of submarine warfare was likely due  ", 20, 190);
                g.drawString("to the outcome of the Battle Jutland, a naval conflict lasting two ", 20, 210);
                g.drawString("days, from May 31 to June 1, 1916.", 100, 230);
                g.drawString("This battle took place off the course of the Jutland Denmark ", 20, 270);
                g.drawString("Peninsula and was fought between the British and Germany.The battle ", 20, 290);
                g.drawString("commenced whencommander of the German High Seas Fleet,Vice  ", 20, 310);
                g.drawString("Admiral Reinhard Scheer, decided the time was right to attack the  ", 20, 330);
                g.drawString("British coastline and attempt todestroy the barricade of British ships. ", 20, 350);
                g.drawString("Thiswas the largest naval battle inthe first world war and the only one  ", 20, 370);
                g.drawString("where large warships were used on both sides. Though Germany had only ", 20, 390);
                g.drawString("suffered half the losses of life that Britain did (3,000 deaths ", 20, 410);
                g.drawString("compared to 6,000), they were unable to break open the  Allied  ", 20, 430);
                g.drawString("blockadeleading to a British victory. Germany then decided to not  ", 20, 450);
                g.drawString("make any more attempts to break the blockade and devoted the  ", 20, 470);
                g.drawString("remainder of their sea endeavours to unrestricted submarine warfare. ", 20, 490);
                break;
            case 3:
               g.setColor(Color.YELLOW);
               g.setFont(Body);
               g.drawString("Congratulations captain! You have made it back to shore once again,", 20, 50);
               g.drawString("this time for good. Your efforts will do numbers for the Allied forces", 20, 70);
               g.drawString("and hopefully this conflict will cease soon enough.", 50, 90);
               g.drawString("The Royal Navy soon realized that the Allied forces must engage in ", 20, 130);
               g.drawString("Anti-Submarine ounter attacks to disrupt the German Navy and  ", 20, 150);
               g.drawString("prevent more merchant ships from sinking. The first of these", 20, 170);
               g.drawString("countermeasures was the Board of Invention and Research, which  ", 20, 190);
               g.drawString("took over 14,000 suggestions from the public for ways to combat ", 20, 210);
               g.drawString("U-Boats, though most ofAnti-Submarine measures were later taken  ", 20, 230);
               g.drawString("care of by the Anti-Submarine Division.", 120, 250);
               
               g.drawString("The first U-Boat that was successfully destroyed by Allied Forces was ", 20, 290);
               g.drawString("the U-68, sunk by the British ship the HMS Farnborough on March 22, ", 20, 310);
               g.drawString("1916. This proved to be a major stepping stone in efforts against ", 20, 330);
               g.drawString("German subs. The Anti-Submarine Division went on to develop and ", 20, 350);
               g.drawString("implement various ideas to take down U-Boats, such as indicator loops ", 20, 370);
               g.drawString("that detected magnetic fields from U-Boats in 1917, which vastly ", 20, 390);
               g.drawString("improved the tracking of U-Boats. The most important of these ideas ", 20, 410);
               g.drawString("was the  introduction of escorted convoys, which brought down the  ", 20, 430);
               g.drawString("loss of ships entering the war zone from 25% to 1%. Thanks to these ", 20, 450);
               g.drawString("efforts 178 out of the 360 German U-Boats were destroyed in the ", 20, 470);
               g.drawString("Great War.", 220, 490);
               
               break;
            
        }
        
        g.setColor(Color.white);
        
    }
}
    
    public boolean keyDown (Event e, int key){
        if (key==Event.LEFT){
            isLeft=true;
        }
        if (key==Event.RIGHT){
            isRight=true;
        }
        if ((key==32) && (distance==0)){
            if (Level != 3){
                distance=1200;
                Level+=1;
                lives=3;
                speed+=2;
            }
        }
        System.out.println("Integer Value: " + key);
        return true;
    }
    
    public boolean keyUp(Event e, int key){
        if (key==Event.LEFT){
            isLeft=false;
        }
        if (key==Event.RIGHT){
            isRight=false;
        }
        return true;
    }

}

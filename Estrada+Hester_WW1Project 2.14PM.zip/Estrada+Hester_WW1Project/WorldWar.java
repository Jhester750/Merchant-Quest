
import java.awt.*;
import java.applet.*;

/**
 * Class WorldWar - write a description of the class here
 * 
 * @author (your name) 
 * @version (a version number)
 */
public class WorldWar extends Applet implements Runnable {
    Graphics bufferGraphics;
    Image display;
    boolean isRight=false;
    boolean isLeft=false;
    int direction=1;
    double shipX=250;
    int shipWidth=24;
    Image ship;
    public void init()
    {
        setBackground(Color.blue);
        display=createImage(getSize().width,getSize().height);
        bufferGraphics=display.getGraphics();
        ship=getImage(getDocumentBase(), "merchant.png");
        new Thread(this).start();
    }

    public void run()
    {
        for(;;){
            if (isRight==true){
                if (shipX<getSize().width-shipWidth){
                    shipX+=3;
                }
            }
            if (isLeft==true){
                if (shipX>0){
                    shipX-=3;}
           }
           repaint();
           try  {
               Thread.sleep(16);
            }
            catch(InterruptedException e){
            }
        }
                
    }

    public void update(Graphics g)
    {
        
        g.drawImage(display,0,0,this);
        g.drawImage(ship, (int)shipX, 375, 100,100, this);
    }
    
    public boolean keyDown (Event e, int key){
        if (key==Event.LEFT){
            isLeft=true;
        }
        if (key==Event.RIGHT){
            isRight=true;
        }
        System.out.println("Integer Value: " + key);
        return true;
    }
    
    public boolean keyUp(Event e, int key){
        if (key==Event.LEFT){
            isLeft=false;
        }
        if (key==Event.RIGHT){
            isRight=false;
        }
        return true;
    }
   
}

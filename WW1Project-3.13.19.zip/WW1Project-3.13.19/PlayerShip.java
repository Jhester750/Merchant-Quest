public class PlayerShip
{
    // instance variables - replace the example below with your own
    public static final int SIZE = 20;
    public int shipX;
    public int shipY;
    public int shipLeft;
    public int shipRight;

    public PlayerShip ( int canvasSize )
    {
        shipX = canvasSize / 2;
        shipY = canvasSize * 3 / 4;
    }

    public void moveLeft ()
    {
        shipX -= 1;
    }

    public void moveRight ()
    {
        shipX += 1;
    }

    public int getLeftBound ()
    {
        int leftSide = Math.round( shipX - ( SIZE / 2 ) );
        return ( leftSide );
    }

    public int getWidth ()
    {
        return SIZE;
    }

    public int getTopBound ()
    {
        int topSide = Math.round( shipY - ( SIZE / 2 ) );
        return ( topSide );
    }

    public int getHeight ()
    {
        return SIZE;
    }

}
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Renderer extends JApplet implements KeyListener
{
    public PlayerShip playerShip;
    public static final int CANVAS_SIZE = 500;
    public static final int FRAMES_PER_SECOND = 20;
    public static final int SKIP_TICKS = 1000 / FRAMES_PER_SECOND;

    public void initLevel ()
    {
        playerShip = new PlayerShip( CANVAS_SIZE );
    }

    public void paint ( Graphics g )
    {
        int sleep_time = 0;
        int next_game_tick = 0;
        long sleepTime;
        boolean isGame = true;
        long startTime = System.currentTimeMillis();
        setSize( CANVAS_SIZE , CANVAS_SIZE );
        while ( isGame  )
        {
            initLevel();
            int leftSide = playerShip.getLeftBound();
            int width = playerShip.getWidth();
            int topSide = playerShip.getTopBound();
            int height = playerShip.getHeight();

            g.setColor( Color.BLUE );
            g.fillRect( 0 , 0 , CANVAS_SIZE , CANVAS_SIZE );
            g.setColor( Color.ORANGE );
            g.fillRect( leftSide , topSide , width , height );
            long timeElapsed = System.currentTimeMillis() - startTime;
            next_game_tick += SKIP_TICKS;

            sleepTime = next_game_tick - timeElapsed;
            try
            {
                Thread.sleep( sleepTime );
            } catch ( InterruptedException ex )
            {
                Thread.currentThread().interrupt();
            }

        }

    }

    //----------|  Override `java.awt.event.KeyListener`  |------------------

    @Override
    public void keyPressed ( KeyEvent e )
    {
        if ( e.getKeyCode() == KeyEvent.VK_RIGHT )
        {
            playerShip.moveRight();
        } else if ( e.getKeyCode() == KeyEvent.VK_LEFT )
        {
            playerShip.moveLeft();
        }
        repaint();
    }

    @Override
    public void keyTyped ( KeyEvent e )
    {
        // No code needed here.
    }

    @Override
    public void keyReleased ( KeyEvent e )
    {
        // No code needed here.
    }

}
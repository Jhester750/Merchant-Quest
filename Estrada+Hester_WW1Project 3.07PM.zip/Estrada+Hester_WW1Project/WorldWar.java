
import java.awt.*;
import java.applet.*;

/**
 * Class WorldWar - write a description of the class here
 * 
 * @author (your name) 
 * @version (a version number)
 */
public class WorldWar extends Applet implements Runnable {
    Graphics bufferGraphics;
    Image display;
    boolean isRight=false;
    boolean isLeft=false;
    int direction=1;
    double playerShipX=250;
    int shipWidth=24;
    Image playerShip;
    Image enemyShip;
    double enemyShipX=250;
    public void init()
    {
        setBackground(Color.blue);
        display=createImage(getSize().width,getSize().height);
        bufferGraphics=display.getGraphics();
        playerShip=getImage(getDocumentBase(), "playerShip.png");
        enemyShip=getImage(getDocumentBase(), "enemyShip.png");
        new Thread(this).start();
    }

    public void run()
    {
        for(;;){
            if (isRight==true){
                if (playerShipX<getSize().width-shipWidth){
                    playerShipX+=3;
                }
            }
            if (isLeft==true){
                if (playerShipX>0){
                    playerShipX-=3;}
           }
           repaint();
           try  {
               Thread.sleep(16);
            }
            catch(InterruptedException e){
            }
        }
                
    }

    public void paint(Graphics g)
    {
        g.drawImage(display,0,0,this);
        g.drawImage(playerShip, (int)playerShipX, 375, 100, 100, this);
        g.drawImage(enemyShip, (int)enemyShipX, 50, 100, 100, this);
    }
    
    public boolean keyDown (Event e, int key){
        if (key==Event.LEFT){
            isLeft=true;
        }
        if (key==Event.RIGHT){
            isRight=true;
        }
        System.out.println("Integer Value: " + key);
        return true;
    }
    
    public boolean keyUp(Event e, int key){
        if (key==Event.LEFT){
            isLeft=false;
        }
        if (key==Event.RIGHT){
            isRight=false;
        }
        return true;
    }
   
}

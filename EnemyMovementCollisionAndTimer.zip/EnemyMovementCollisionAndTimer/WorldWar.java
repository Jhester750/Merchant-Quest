
import java.awt.*;
import java.applet.*;
import java.util.Random;
/**
 * Class WorldWar - write a description of the class here
 * 
 * @author Jack + Neil 
 * @version March 15, 2019 3:07 PM
 */
public class WorldWar extends Applet implements Runnable {
    Graphics bufferGraphics;
    Image display;
    boolean isRight=false;
    boolean isLeft=false;
    boolean isRunning=true;
    double playerShipX=250;
    double playerShipY=400;
    int shipWidth=24;
    Image playerShip;
    Image enemyShip;
    Image fireball;
    double enemyShipX=250;
    double enemyShipY=0;
    int lives=3;
    Random rand = new Random();
    public static final int SIZE = 70;
    int distance=2000;
    String dMessage;
    public void init()
    {
        setBackground(Color.blue);
        display=createImage(getSize().width,getSize().height);
        bufferGraphics=display.getGraphics();
        playerShip=getImage(getDocumentBase(), "playerShipNew.png");
        enemyShip=getImage(getDocumentBase(), "enemyShip.png");
        fireball=getImage(getDocumentBase(), "fireball.png");
        new Thread(this).start();
    }

    public void run()
    {
        while (isRunning==true){
            if (isRight==true){
                if (playerShipX<getSize().width-shipWidth){
                    playerShipX+=6;
                }
            }
            if (isLeft==true){
                if (playerShipX>0){
                    playerShipX-=6;}
           }
           if (enemyShipY > 500-SIZE){
               enemyShipY= 0;
               enemyShipX = rand.nextInt(500-SIZE);
            }
           else{
               enemyShipY +=3;
            }
           distance-=1;
           dMessage= "You are "+distance+" miles from shore";
           repaint();
           
           if (lives==0){
               isRunning=false;
            }
           try  {
               Thread.sleep(32);
            }
            catch(InterruptedException e){
            }
        }
                
    }

    public void paint(Graphics g)
    {
        g.drawImage(display,0,0,this);
        g.drawImage(playerShip, (int)playerShipX, (int)playerShipY, SIZE, SIZE, this);
        g.drawImage(enemyShip, (int)enemyShipX, (int)enemyShipY, SIZE, SIZE, this);
        g.drawString(dMessage, 20, 20);
        if (((playerShipX > enemyShipX-SIZE) &&(playerShipX < enemyShipX+SIZE))&&((playerShipY > enemyShipY-SIZE) &&(playerShipY < enemyShipY+SIZE))){
            g.drawImage(fireball,(int)playerShipX-SIZE/2, (int)playerShipY-SIZE/2, SIZE*2, SIZE*2, this);
            isRunning=false;
        }
        
    }
    
    public boolean keyDown (Event e, int key){
        if (key==Event.LEFT){
            isLeft=true;
        }
        if (key==Event.RIGHT){
            isRight=true;
        }
        System.out.println("Integer Value: " + key);
        return true;
    }
    
    public boolean keyUp(Event e, int key){
        if (key==Event.LEFT){
            isLeft=false;
        }
        if (key==Event.RIGHT){
            isRight=false;
        }
        return true;
    }
   
}
